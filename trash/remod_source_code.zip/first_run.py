from extract_swc_morphology import *
from neuron_before_swc import *
from statistics_swc import *
import sys

if (len(sys.argv)==3):
	abs_path=str(sys.argv[1])
	file_name=str(sys.argv[2])
	fname=abs_path+file_name

else:
	sys.exit(0)

(swc_lines, points, comment_lines, parents, bpoints, soma_index, max_index, dlist, dend_points, dend_names, exceptions, basal, apical, dend_add3d, path, all_terminal, basal_terminal, apical_terminal, dist, bo, con, point_lines, ppoints)=read_file(fname) #extracts important connectivity and morphological data

first_graph(swc_lines, dlist, dend_add3d, abs_path, file_name) #plots the original and modified tree (overlaying one another)

file_name=file_name.replace('.swc','')

fdendlist=abs_path+file_name+'_dendritic_list.txt'
f = open(fdendlist, 'w')
for dend in dlist:
	print >>f, dend
f.close()

fdendlength=abs_path+'downloads/statistics/'+'dendritic_lengths.txt' # <--------- temporary
#fdendlength=abs_path+file_name+'_dendritic_lengths.txt'
f = open(fdendlength, 'w')
for dend in dlist:
	print >>f, str(dend) + ' ' + str(dist[dend])
f.close()

fnumdend=abs_path+'downloads/statistics/'+'number_of_dendrites.txt'
#fnumdend=abs_path+file_name+'_number_of_dendrites.txt'
f = open(fnumdend, 'w')
print >>f, 'basal' + ' ' + str(len(basal)) + ' ' + str(len(basal_terminal))
print >>f, 'apical' + ' ' + str(len(apical)) + ' ' + str(len(apical_terminal))
f.close()

bo=branch_order(dlist, path)
(bo_freq, bo_max)=bo_frequency(dlist, bo)
fbo=abs_path+'downloads/statistics/'+'branch_order_frequency.txt'
#fbo=abs_path+file_name+'_branch_order_frequency.txt'
f = open(fbo, 'w')
for order in bo_freq:
	print >>f, str(order) + ' ' + str(bo_freq[order])
f.close()

bo_dlen=bo_dlength(dlist, bo, bo_max, dist)
fbo_dlen=abs_path+'downloads/statistics/'+'bo_average_dlength.txt'
#fbo_dlen=abs_path+file_name+'_bo_average_dlength.txt'
f = open(fbo_dlen, 'w')
for order in bo_dlen:
	print >>f, str(order) + ' ' + str(bo_dlen[order])
f.close()

plength=path_length(dlist, path, dist)
bo_plen=bo_plength(dlist, bo, bo_max, plength)
fbo_plen=abs_path+'downloads/statistics/'+'bo_average_plength.txt'
#fbo_plen=abs_path+file_name+'_bo_average_plength.txt'
f = open(fbo_plen, 'w')
for order in bo_dlen:
	print >>f, str(order) + ' ' + str(bo_plen[order])
f.close()

sholl(dlist, dend_add3d, ppoints, points, bo, con, point_lines, soma_index)