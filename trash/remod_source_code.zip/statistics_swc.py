import re
from math import sqrt
from random import randint
import sys

import numpy as np
from random import uniform, randrange
from math import cos, sin, pi, sqrt, radians, degrees

def path_length(dlist, path, dist):
	plength=dict()
	for dend in dlist:
		d=0
		for i in path[dend]:
			d+=dist[i]
		plength[dend]=d
	return plength

def branch_order(dlist, path):
	bo=dict()
	for dend in dlist:
		bo[dend]=len(path[dend])-1
	return bo

def bo_frequency(dlist, bo):

	orders=[]
	for dend in dlist:
		orders.append(bo[dend])

	bo_min=1 # min(orders)
	bo_max=max(orders)

	bo_freq={}

	for i in range(bo_min, bo_max+1):
		k=0
		for order in orders:
			if order==i:
				k+=1
		bo_freq[i]=k

	return bo_freq, bo_max

def bo_dlength(dlist, bo, bo_max, dist):

	bo_dlen={}
	for i in range(1, bo_max+1):

		k=0
		add_length=0

		for dend in dlist:
			if i==bo[dend]:
				k+=1
				add_length+=dist[dend]
				#print str(dend) + ' ' + str(bo[dend]) + ' ' + str(dist[dend])

		if k!=0:
			bo_dlen[i]=add_length/k

	return bo_dlen

def bo_plength(dlist, bo, bo_max, plength):

	print dlist

	bo_plen={}
	for i in range(1, bo_max+1):

		k=0
		add_length=0

		for dend in dlist:
			if i==bo[dend]:
				k+=1
				add_length+=plength[dend]
				#print str(dend) + ' ' + str(bo[dend]) + ' ' + str(dist[dend])

		if k!=0:
			bo_plen[i]=add_length/k

	return bo_plen

def distance(x1,x2,y1,y2,z1,z2): #returns the euclidean distance between two 3d points

	dist = sqrt((x2-x1)**2 + (y2-y1)**2 + (z2-z1)**2)
	return dist

def sholl(dlist, dend_add3d, ppoints, points, bo, con, point_lines, soma_index):
	for i in soma_index:
		if i[1]==1:
			xr=i[2]
			yr=i[3]
			zr=i[4]
	
	for oc in range(1,27):

		val=oc*20
		intersection=0

		for dend in dlist:

			k=0

			for i in dend_add3d[dend]:

				if k==0:
					pass

				else:
					previous_dist=mydist

				x=i[2]
				y=i[3]
				z=i[4]

				mydist=distance(xr,x,yr,y,zr,z)

				if k==0:
					pass

				else:

					if val>previous_dist and val<mydist:

						intersection+=1

				k+=1

		print val, intersection