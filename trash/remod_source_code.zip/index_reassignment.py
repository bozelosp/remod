def index_reassign(dlist, dend_add3d, bo, con, point_lines):
	
	print 'Con', con

	bo_sorted_dends=[]
	for i in range(0,20):
		for dend in dlist:
			if bo[dend]==i:
				bo_sorted_dends.append(dend)

	mylist=[]
	ind=1
	for i in point_lines:
		tmp=i.split()
		if int(tmp[1])==1:
			if int(tmp[0])==1:
				mylist.append([int(ind), int(tmp[1]), float(tmp[2]), float(tmp[3]), float(tmp[4]), float(tmp[5]), -1])
			else:
				mylist.append([int(ind), int(tmp[1]), float(tmp[2]), float(tmp[3]), float(tmp[4]), float(tmp[5]), int(tmp[6])])
			ind+=1
	
	index=ind
	
	for dend in bo_sorted_dends:

		for i in range(len(dend_add3d[dend])):

			if bo[dend]==0:

				if i==0:
					dend_add3d[dend][i][0]=index
					dend_add3d[dend][i][6]=1
					previous=index
					index+=1
					mylist.append(dend_add3d[dend][i])

				else:
					dend_add3d[dend][i][0]=index
					dend_add3d[dend][i][6]=previous
					previous=index				
					index+=1
					mylist.append(dend_add3d[dend][i])

			if bo[dend]>0:

				if i==0:
					dend_add3d[dend][i][0]=index
					parent_dend=con[dend]
					parent_point=dend_add3d[parent_dend][-1]
					dend_add3d[dend][i][6]=parent_point[0]
					previous=index
					index+=1
					mylist.append(dend_add3d[dend][i])

				else:
					dend_add3d[dend][i][0]=index
					dend_add3d[dend][i][6]=previous
					previous=index				
					index+=1
					mylist.append(dend_add3d[dend][i])

	newfile=[]
	for k in mylist:
		m=' %d %d %.2f %.2f %.2f %.2f %d' % (k[0], k[1], k[2], k[3], k[4], k[5], k[6])
		newfile.append(m)

	return newfile
