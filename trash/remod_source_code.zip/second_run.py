from extract_swc_morphology import *
from take_action_swc import *
from warn import *
from graph import *
from index_reassignment import *
from os import remove
import sys
import datetime

#python second_run.py /home/bozelosp/Dropbox/remod/swc/ 0-2.swc who_all_terminal 0 none none percent 50 percent 50
#python second_run.py /Users/bozelosp/Dropbox/remod/swc/ 0-2.swc who_all_terminal 0 none none percent 50 percent 50
#python second_run.py /Users/bozelosp/Dropbox/remod/swc/ 0-2.swc who_all_terminal 0 none extend percent 20 none none 
#python second_run.py /Users/bozelosp/Dropbox/remod/swc/ 0-2.swc who_apical_terminal 0 none none percent none percent 10 
if (len(sys.argv)==11):
	directory=str(sys.argv[1])
	file_name=str(sys.argv[2])
	fname=str(sys.argv[1])+str(sys.argv[2])

	who=str(sys.argv[3])
	who_random_variable=str(sys.argv[4])
	who_manual_variable=str(sys.argv[5])
	action=str(sys.argv[6])
	hm_choice=str(sys.argv[7])
	amount=sys.argv[8]
	var_choice=str(sys.argv[9])
	diam_change=sys.argv[10]
else:
	sys.exit(0)

print
print 'Open file: ' + str(file_name) + ' !'
print

(swc_lines, points, comment_lines, parents, bpoints, soma_index, max_index, dlist, dend_points, dend_names, exceptions, basal, apical, dend_add3d, path, all_terminal, basal_terminal, apical_terminal, dist, bo, con, point_lines, ppoints)=read_file(fname) #extracts important connectivity and morphological data

print 'apical terminal: ' + str(apical_terminal)

#regex_who=re.search('(.*)', choices[0])
#who=regex_who.group(1)
if who=='who_all_terminal':
	who=all_terminal
if who=='who_apical_terminal':
	who=apical_terminal
if who=='who_basal_terminal':
	who=basal_terminal
if who=='who_random_all':
	who=random_all
if who=='who_random_apical':
	who=random_apical
if who=='who_random_basal':
	who=random_basal
if who=='who_manual':
	who=apical_terminal

print
for dend in dlist:
	print dend, dist[dend], dend_points[dend]
print

#regex_action=re.search('(.*)', choices[1])
#action=regex_action.group(1)

#hm=choices[2].split()
#if hm[0]=="hm_choice:":
#	hm_choice=hm[1]

#am=choices[3].split()
#if am[0]=="amount:":
#	amount=int(am[1])

#diam=choices[4].split()
#if diam[0]=="diameter_change:":
#	diam_change=diam[1]

#print who, action, amount, hm_choice
#check_terminal(who, all_terminal) #checks if selected dendrites are terminal

now = datetime.datetime.now()

edit='#REMOD edited the original ' + str(file_name) + ' file as follows: ' + 'terminal basal ' + 'dendrites: ' + str(who) + ', action: ' + str(action) + ', extent percent/um: ' + str(hm_choice) + ', amount: ' + str(amount) + ', diameter percent/um: ' + str(var_choice) + ', diameter change: ' + str(diam_change) + " - This file was modified on " + str(now.strftime("%Y-%m-%d %H:%M")) + '\n#'

(newfile, dlist,mylist)=execute_action(who, action, amount, hm_choice, dend_add3d, dist, max_index, diam_change, dlist, soma_index, points, ppoints) #executes the selected action and print the modified tree to a '*_new.hoc' file

newfile=comment_lines + newfile

if action == "branch":

	mylist=[]
	for i in point_lines:
		tmp=i.split()
		if int(tmp[1])==1:
			mylist.append([int(tmp[0]), int(tmp[1]), float(tmp[2]), float(tmp[3]), float(tmp[4]), float(tmp[5]), int(tmp[6])])

	for k in mylist:
		m=' %d %d %.2f %.2f %.2f %.2f %d' % (k[0], k[1], k[2], k[3], k[4], k[5], k[6])
		if m not in newfile:
			newfile.insert(0,m)

	#newfile.sort()

	new_name=print_newfile_tmp(directory, file_name, newfile, edit)

	(swc_lines, points, comment_lines, parents, bpoints, soma_index, max_index, dlist, dend_points, dend_names, exceptions, basal, apical, dend_add3d, path, all_terminal, basal_terminal, apical_terminal, dist, bo, con, point_lines)=read_file(new_name)

	remove(new_name)


if action == 'shrink':
	newfile=index_reassign(dlist, dend_add3d, bo, con, point_lines)

check_indices(newfile) #check if indices are continuous from 0 and u

newfile=comment_lines + newfile
print_newfile(directory, file_name, newfile, edit)

print

print
print 'File: ' + str(file_name) + ' succesfully edited!'
print

print
print '--------------------------------'
print

#graph(swc_lines, newfile, action, dend_add3d, dlist, directory, file_name) #plots the original and modified tree (overlaying one another)

'''for dend in dlist:
	print dend, dend_points[dend]
	print

print
print
for dend in dlist:
	print dend, path[dend]

print
print
for dend in all_terminal:
	print dend, path[dend]'''
